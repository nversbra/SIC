/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.javacard.samples.odSample.packageB;

/**
 * Class represents node in a tree contained in B.java
 **/
public class BTreeNode {
  public short data;
}
