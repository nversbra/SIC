/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/*
 * PreProcess.java
 *
 * Created on October 8, 2001, 2:11 PM
 */

package com.sun.javacard.samples.ServiceDemo;

/**
 *
 * @author  vo113324
 */
public class PreProcess {

    /** Creates new PreProcess */
    public PreProcess() {
    }

}
